# Hadi Edge App + Cloudflare

This version is prepared for use behind Cloudflare proxy.

## Setup
1. Upload this project to Netlify
2. Connect your custom domain in Netlify
3. Add the same domain to Cloudflare
4. In Cloudflare DNS:
   - Create a CNAME record pointing to your Netlify domain
   - Enable the orange cloud (Proxy ON)

## Recommended Cloudflare Settings
- SSL/TLS: Full
- Always Use HTTPS: ON
- Automatic HTTPS Rewrites: ON
- Caching: Standard

## Notes
- Traffic will pass through Cloudflare before reaching Netlify.
- Edge Functions remain active normally.
